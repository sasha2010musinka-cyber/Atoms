# AtomSphere (Paper 1.21.11)
/atom [scale] [here] — запуск (зарядка -> атом -> выброс энергии)
/atom stop — остановить
Право: atomsphere.use (по умолчанию op)
Сборка: mvn package -> target/AtomSphere.jar

package ru.atomsphere;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Фазы: CHARGE (зарядка) -> ACTIVE (атом: сфера + электроны + блоки) -> RELEASE (выброс энергии).
 */
public class AtomEffect extends BukkitRunnable {

    private static final int CHARGE = 110;
    private static final int ACTIVE = 320;
    private static final int RELEASE = 70;
    private static final int TOTAL = CHARGE + ACTIVE + RELEASE;
    private static final double GOLDEN = Math.PI * (3 - Math.sqrt(5));

    private static final Color WHITE = Color.fromRGB(255, 255, 255);
    private static final Color CYAN = Color.fromRGB(0, 220, 255);
    private static final Color PURPLE = Color.fromRGB(160, 70, 255);

    private static class Electron {
        final double tiltX, tiltZ, speed, phase, dir;
        final Color c1, c2;
        final Material[] mats;

        Electron(double tiltX, double tiltZ, double speed, double phase, double dir,
                 Color c1, Color c2, Material... mats) {
            this.tiltX = tiltX;
            this.tiltZ = tiltZ;
            this.speed = speed;
            this.phase = phase;
            this.dir = dir;
            this.c1 = c1;
            this.c2 = c2;
            this.mats = mats;
        }
    }

    private static class Item {
        BlockDisplay d;
        int electron;
        double phase;
        float baseSize;
        Location pos;
        Vector vel;
        Color color = WHITE;
    }

    private final AtomSpherePlugin plugin;
    private final World world;
    private final Location center;
    private final double scale;
    private final double sphereR;
    private final double orbitR;
    private final Random rnd = new Random();

    private int tick = 0;
    private boolean done = false;

    private final List<Item> chargeBlocks = new ArrayList<>();
    private final List<Item> orbitBlocks = new ArrayList<>();

    private final Electron[] electrons = {
            new Electron(0.0, 0.0, 0.075, 0.0, 1, Color.fromRGB(0, 230, 255), Color.fromRGB(0, 90, 255),
                    Material.SEA_LANTERN, Material.DIAMOND_BLOCK, Material.PRISMARINE_BRICKS),
            new Electron(1.05, 0.0, 0.090, 2.1, -1, Color.fromRGB(255, 70, 220), Color.fromRGB(150, 40, 255),
                    Material.CRYING_OBSIDIAN, Material.AMETHYST_BLOCK, Material.PURPUR_BLOCK),
            new Electron(-1.05, 0.0, 0.065, 4.2, 1, Color.fromRGB(255, 210, 50), Color.fromRGB(255, 110, 20),
                    Material.GLOWSTONE, Material.GOLD_BLOCK, Material.SHROOMLIGHT),
            new Electron(0.0, Math.PI / 2, 0.100, 1.0, -1, Color.fromRGB(90, 255, 130), Color.fromRGB(20, 190, 90),
                    Material.EMERALD_BLOCK, Material.SLIME_BLOCK, Material.VERDANT_FROGLIGHT)
    };

    public AtomEffect(AtomSpherePlugin plugin, Location center, double scale) {
        this.plugin = plugin;
        this.world = center.getWorld();
        this.center = center.clone();
        this.scale = scale;
        this.sphereR = 2.2 * scale;
        this.orbitR = 5.6 * scale;
    }

    // ------------------------------------------------------------------ main loop

    @Override
    public void run() {
        if (done) return;
        if (tick >= TOTAL) {
            stop();
            return;
        }
        try {
            if (tick < CHARGE) charge();
            else if (tick < CHARGE + ACTIVE) active();
            else release();
        } catch (Exception ex) {
            plugin.getLogger().warning("AtomEffect error: " + ex);
            stop();
            return;
        }
        tick++;
    }

    public void stop() {
        if (done) return;
        done = true;
        removeAll(chargeBlocks);
        removeAll(orbitBlocks);
        plugin.unregister(this);
        try {
            cancel();
        } catch (IllegalStateException ignored) {
        }
    }

    private void removeAll(List<Item> list) {
        for (Item it : list) if (it.d != null) it.d.remove();
        list.clear();
    }

    // ------------------------------------------------------------------ phase 1: charge

    private void charge() {
        double p = tick / (double) CHARGE;
        double e = p * p * (3 - 2 * p);
        double spin = tick * 0.06 * (1 + p * 2);

        if (tick == 0) {
            Material[] all = {Material.SEA_LANTERN, Material.CRYING_OBSIDIAN, Material.GLOWSTONE,
                    Material.EMERALD_BLOCK, Material.AMETHYST_BLOCK, Material.DIAMOND_BLOCK, Material.SHROOMLIGHT};
            for (int i = 0; i < 14; i++) {
                Item it = makeItem(all[i % all.length], center);
                it.phase = i * (Math.PI * 2 / 14.0);
                it.color = electrons[i % electrons.length].c1;
                chargeBlocks.add(it);
            }
            world.playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 4f, 0.6f);
        }
        if (tick % 8 == 0) {
            world.playSound(center, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 3f, (float) (0.5 + p * 1.5));
        }

        // растущая сфера-оболочка
        double r = sphereR * (0.15 + 0.85 * e);
        int n = 30 + (int) (40 * p);
        for (int i = 0; i < n; i++) {
            Vector v = fib(i, n).rotateAroundY(spin).multiply(r);
            transition(center.clone().add(v), WHITE, CYAN, 1.0f);
        }

        // ядро
        dust(center, WHITE, (float) (1.5 + 2.5 * p));
        world.spawnParticle(Particle.END_ROD, center, 2, 0.15 * scale, 0.15 * scale, 0.15 * scale, 0.01, null, true);

        // втягивание энергии
        int streams = 4 + (int) (7 * p);
        for (int i = 0; i < streams; i++) {
            double dist = sphereR * 3.4 * (1.3 - 0.6 * p);
            Vector off = randomUnit().multiply(dist);
            Location from = center.clone().add(off);
            Vector to = off.clone().multiply(-1).normalize();
            world.spawnParticle(i % 3 == 0 ? Particle.ELECTRIC_SPARK : Particle.END_ROD, from, 0,
                    to.getX(), to.getY(), to.getZ(), dist * 0.09, null, true);
        }

        // блоки по спирали внутрь
        for (Item it : chargeBlocks) {
            double ang = it.phase + tick * 0.09 * (1 + p);
            double rad = scale * (8.0 * (1 - e) + 0.8);
            double y = Math.sin(it.phase * 2.3 + tick * 0.07) * rad * 0.55;
            Vector v = new Vector(Math.cos(ang) * rad, y, Math.sin(ang) * rad);
            Location l = center.clone().add(v);
            float size = (float) (scale * (0.55 - 0.25 * e));
            place(it, l, size, tick * 0.05f, tick * 0.08f, tick * 0.03f);
            dust(l, it.color, 1.0f);
        }

        // финал зарядки
        if (tick == CHARGE - 1) {
            removeAll(chargeBlocks);
            world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 1, 0, 0, 0, 0, null, true);
            for (int i = 0; i < 80; i++) {
                Vector d = randomUnit();
                world.spawnParticle(Particle.FIREWORK, center, 0, d.getX(), d.getY(), d.getZ(), 0.5, null, true);
            }
            world.playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 3f, 1.6f);
        }
    }

    // ------------------------------------------------------------------ phase 2: atom

    private void active() {
        int t = tick - CHARGE;
        double over = Math.max(0, (t - (ACTIVE - 70)) / 70.0); // 0..1 перед выбросом
        double speedMul = 1 + over * 2.5;
        double gspin = t * 0.015 * (1 + over);
        double oR = orbitR * (1 - 0.35 * over);

        if (t == 0) {
            for (int ei = 0; ei < electrons.length; ei++) {
                for (int k = 0; k < 3; k++) {
                    Item it = makeItem(electrons[ei].mats[k], center);
                    it.electron = ei;
                    it.phase = k * (Math.PI * 2 / 3.0);
                    it.baseSize = (float) (0.5 * scale);
                    it.color = electrons[ei].c1;
                    orbitBlocks.add(it);
                }
            }
            world.playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL, 2f, 1.5f);
        }
        if (t % 40 == 0) world.playSound(center, Sound.BLOCK_BEACON_AMBIENT, 3f, 1f);
        if (over > 0 && t % 5 == 0) {
            world.playSound(center, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 3f, (float) (0.6 + over * 1.4));
        }

        // сфера
        double pulse = 1 + 0.03 * Math.sin(t * 0.2) + over * 0.1 * (rnd.nextDouble() - 0.5) * 2;
        double r = sphereR * pulse;
        int n = 70;
        for (int i = 0; i < n; i++) {
            Vector v = fib(i, n).rotateAroundY(t * 0.05).rotateAroundX(t * 0.025).multiply(r);
            transition(center.clone().add(v), CYAN, PURPLE, 1.1f);
        }
        // два вращающихся кольца вокруг сферы
        for (int ring = 0; ring < 2; ring++) {
            int pts = 44;
            for (int i = 0; i < pts; i++) {
                if ((i & 1) != (tick & 1)) continue;
                double a = i * Math.PI * 2 / pts + t * 0.06 * (ring == 0 ? 1 : -1);
                Vector v = new Vector(Math.cos(a), 0, Math.sin(a)).multiply(sphereR * 1.3);
                v.rotateAroundX(ring == 0 ? 0.5 : -0.5).rotateAroundZ(t * 0.02 * (ring == 0 ? 1 : -1));
                dust(center.clone().add(v), WHITE, 0.9f);
            }
        }
        // ядро
        dust(center, WHITE, (float) (3.0 + over * 2));
        world.spawnParticle(Particle.END_ROD, center, 3, 0.25 * scale, 0.25 * scale, 0.25 * scale, 0.02, null, true);
        // искры из ядра
        int sparks = 3 + (int) (over * 12);
        for (int i = 0; i < sparks; i++) {
            Vector d = randomUnit();
            Location from = center.clone().add(d.clone().multiply(sphereR));
            world.spawnParticle(Particle.ELECTRIC_SPARK, from, 0, d.getX(), d.getY(), d.getZ(), 0.3, null, true);
        }

        // электроны
        for (int ei = 0; ei < electrons.length; ei++) {
            Electron el = electrons[ei];
            double a = el.phase + el.dir * el.speed * t * speedMul;

            // орбита (каждый 2-й пункт за тик)
            int pts = 56;
            for (int i = 0; i < pts; i++) {
                if ((i & 1) != (tick & 1)) continue;
                double aa = i * Math.PI * 2 / pts;
                dust(center.clone().add(orbitPoint(el, aa, oR, gspin)), el.c1, 0.5f);
            }
            // хвост
            for (int k = 1; k <= 16; k++) {
                double ak = a - el.dir * k * 0.055;
                float sz = 1.5f * (1f - k / 18f);
                transition(center.clone().add(orbitPoint(el, ak, oR, gspin)), el.c1, el.c2, Math.max(0.3f, sz));
            }
            // голова
            Location head = center.clone().add(orbitPoint(el, a, oR, gspin));
            dust(head, WHITE, 2.2f);
            transition(head, el.c1, el.c2, 2.0f);
            world.spawnParticle(Particle.END_ROD, head, 2, 0.15 * scale, 0.15 * scale, 0.15 * scale, 0.01, null, true);
            for (int i = 0; i < 5; i++) {
                transition(head.clone().add(randomUnit().multiply(0.35 * scale)), el.c1, el.c2, 0.8f);
            }
        }

        // блоки вокруг электронов
        float grow = Math.min(1f, t / 20f);
        for (Item it : orbitBlocks) {
            Electron el = electrons[it.electron];
            double a = el.phase + el.dir * el.speed * t * speedMul;
            Vector ep = orbitPoint(el, a, oR, gspin);
            double b = t * 0.13 * el.dir + it.phase;
            Vector local = new Vector(Math.cos(b), 0, Math.sin(b)).multiply(1.0 * scale);
            local.rotateAroundX(1.0 + it.electron * 0.5).rotateAroundY(t * 0.05);
            Location l = center.clone().add(ep).add(local);
            it.pos = l.clone();
            place(it, l, it.baseSize * grow, t * 0.07f, t * 0.11f, t * 0.05f);
            if (tick % 2 == 0) dust(l, el.c2, 0.8f);
        }
    }

    // ------------------------------------------------------------------ phase 3: release

    private void release() {
        int r = tick - CHARGE - ACTIVE;

        if (r == 0) {
            world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 3, 0.5 * scale, 0.5 * scale, 0.5 * scale, 0, null, true);
            world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 6f, 0.7f);
            world.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 6f, 1.2f);
            world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 4f, 1f);
            for (Item it : orbitBlocks) {
                Location from = it.pos != null ? it.pos : center;
                Vector dir = from.toVector().subtract(center.toVector());
                if (dir.lengthSquared() < 1.0E-6) dir = randomUnit();
                it.vel = dir.normalize().multiply((0.5 + rnd.nextDouble() * 0.5) * scale);
            }
        }

        // ударная волна
        if (r < 45) {
            double rr = (r + 1) * 0.4 * scale;
            float fade = 1.6f * (1f - r / 45f) + 0.3f;
            int n = 140;
            for (int i = 0; i < n; i++) {
                Vector v = fib(i, n).multiply(rr);
                transition(center.clone().add(v), WHITE, CYAN, fade);
            }
            int pts = 90;
            for (int ring = 0; ring < 3; ring++) {
                for (int i = 0; i < pts; i++) {
                    double a = i * Math.PI * 2 / pts;
                    Vector v = new Vector(Math.cos(a), 0, Math.sin(a)).multiply(rr * 1.15);
                    if (ring == 1) v.rotateAroundX(Math.PI / 2);
                    if (ring == 2) v.rotateAroundZ(Math.PI / 2);
                    world.spawnParticle(Particle.END_ROD, center.clone().add(v), 1, 0, 0, 0, 0, null, true);
                }
            }
        }

        // вспышка частиц наружу
        if (r < 10) {
            for (int i = 0; i < 30; i++) {
                Vector d = randomUnit();
                Particle pt = switch (i % 3) {
                    case 0 -> Particle.FIREWORK;
                    case 1 -> Particle.END_ROD;
                    default -> Particle.ELECTRIC_SPARK;
                };
                world.spawnParticle(pt, center, 0, d.getX(), d.getY(), d.getZ(), 0.6 + rnd.nextDouble() * 0.6, null, true);
            }
        }

        // блоки разлетаются
        double k = 1.0 - r / (double) RELEASE;
        for (Item it : orbitBlocks) {
            if (it.pos == null || it.vel == null) continue;
            it.pos.add(it.vel);
            it.vel.multiply(0.96);
            place(it, it.pos, (float) Math.max(0.02, it.baseSize * k), r * 0.3f, r * 0.4f, r * 0.2f);
            world.spawnParticle(Particle.FLAME, it.pos, 1, 0.05, 0.05, 0.05, 0.01, null, true);
            dust(it.pos, it.color, 1.2f);
        }
    }

    // ------------------------------------------------------------------ helpers

    private Vector orbitPoint(Electron el, double a, double radius, double spin) {
        Vector v = new Vector(Math.cos(a) * radius, 0, Math.sin(a) * radius);
        v.rotateAroundX(el.tiltX);
        v.rotateAroundZ(el.tiltZ);
        v.rotateAroundY(spin * el.dir);
        return v;
    }

    private Vector fib(int i, int n) {
        double y = 1 - 2.0 * (i + 0.5) / n;
        double rad = Math.sqrt(Math.max(0, 1 - y * y));
        double th = GOLDEN * i;
        return new Vector(Math.cos(th) * rad, y, Math.sin(th) * rad);
    }

    private Vector randomUnit() {
        Vector v = new Vector(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian());
        if (v.lengthSquared() < 1.0E-6) return new Vector(0, 1, 0);
        return v.normalize();
    }

    private void dust(Location l, Color c, float size) {
        world.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, new Particle.DustOptions(c, size), true);
    }

    private void transition(Location l, Color from, Color to, float size) {
        world.spawnParticle(Particle.DUST_COLOR_TRANSITION, l, 1, 0, 0, 0, 0,
                new Particle.DustTransition(from, to, size), true);
    }

    private Item makeItem(Material m, Location loc) {
        Item it = new Item();
        it.d = world.spawn(loc, BlockDisplay.class, d -> {
            d.setBlock(m.createBlockData());
            d.setBrightness(new Display.Brightness(15, 15));
            d.setTeleportDuration(3);
            d.setInterpolationDuration(3);
            d.setViewRange(3.0f);
            d.setShadowRadius(0f);
            d.setPersistent(false);
            d.setTransformation(new Transformation(
                    new Vector3f(0, 0, 0), new Quaternionf(), new Vector3f(0.01f, 0.01f, 0.01f), new Quaternionf()));
        });
        return it;
    }

    private void place(Item it, Location loc, float size, float rx, float ry, float rz) {
        if (it.d == null || !it.d.isValid()) return;
        float s = Math.max(0.01f, size);
        Quaternionf q = new Quaternionf().rotationXYZ(rx, ry, rz);
        Vector3f t = new Vector3f(-s / 2f, -s / 2f, -s / 2f).rotate(q);
        it.d.teleport(loc);
        it.d.setInterpolationDelay(0);
        it.d.setTransformation(new Transformation(t, q, new Vector3f(s, s, s), new Quaternionf()));
    }
}

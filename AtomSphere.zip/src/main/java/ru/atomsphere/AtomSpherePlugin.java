package ru.atomsphere;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AtomSpherePlugin extends JavaPlugin implements TabExecutor {

    private final Set<AtomEffect> running = new HashSet<>();

    @Override
    public void onEnable() {
        var cmd = getCommand("atom");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("AtomSphere enabled. Use /atom");
    }

    @Override
    public void onDisable() {
        stopAll();
    }

    void unregister(AtomEffect fx) {
        running.remove(fx);
    }

    private void stopAll() {
        for (AtomEffect fx : new ArrayList<>(running)) fx.stop();
        running.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }
        double scale = 1.0;
        boolean here = false;
        for (String a : args) {
            if (a.equalsIgnoreCase("stop")) {
                stopAll();
                p.sendMessage("§cВсе анимации остановлены.");
                return true;
            } else if (a.equalsIgnoreCase("here")) {
                here = true;
            } else {
                try {
                    scale = Double.parseDouble(a.replace(',', '.'));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        scale = Math.max(0.3, Math.min(3.0, scale));

        Location center;
        if (here) {
            center = p.getLocation().add(0, 3.0 * scale, 0);
        } else {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 1.0E-6) dir = new Vector(0, 0, 1);
            dir.normalize().multiply(10.0 * scale);
            center = p.getLocation().add(dir).add(0, 4.0 * scale, 0);
        }

        AtomEffect fx = new AtomEffect(this, center, scale);
        running.add(fx);
        fx.runTaskTimer(this, 0L, 1L);
        p.sendMessage("§bАтом запущен §7(scale " + scale + "). §8/atom stop — остановить");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of("stop", "here", "0.5", "1", "1.5", "2");
    }
}
